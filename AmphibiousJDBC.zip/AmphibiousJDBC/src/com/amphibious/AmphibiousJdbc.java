package com.amphibious;

import java.sql.*;
import java.util.*;

import javax.naming.spi.DirStateFactory.Result;

import java.io.*;

import com.mysql.jdbc.Driver;
import oracle.jdbc.OracleDriver;

public class AmphibiousJdbc {
	/*
	 * Load and Connect to any DB
	 */
	public static Connection rockAndLoad(String dbUrl,String user,String password, String driverClass){

		Connection con=null;
		try {
			/*
			 * 1- Loading Driver at Runtime
			 */
			DriverManager.registerDriver((java.sql.Driver)Class.forName(driverClass).newInstance());

			/*
			 * 2- getting the Connection
			 */
			con = DriverManager.getConnection(dbUrl, user, password);
			System.out.println("Connection Established\n");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}//end of rockAndLoad

	/*
	 * Issue and Process the query
	 */
	public static void staticQuery(String query, Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		/*
		 * Issue the query
		 */
		if(con !=null){

			try {

				if(query.contains("desc")){
					 stmt = con.createStatement();
					 rs = stmt.executeQuery("select * from emp");
					 rsmd = rs.getMetaData();
					 ArrayList<String> fieldsName = new ArrayList<String>();
					 ArrayList<String> fieldsType = new ArrayList<String>();
					 ArrayList<Integer> fieldsSize = new ArrayList<Integer>();
					 ArrayList<Integer> fieldsIsNullable = new ArrayList<Integer>();
					 for(int i =1;i<=rsmd.getColumnCount();i++){
						 fieldsName.add(rsmd.getColumnName(i));
						 fieldsType.add(rsmd.getColumnTypeName(i));
						 fieldsSize.add(rsmd.getColumnDisplaySize(i));
						 fieldsIsNullable.add(rsmd.isNullable(i));
					 }
					 for(int j=0;j<rsmd.getColumnCount();j++){
							System.out.printf("\t%-10s",fieldsName.get(j));
							
							if(fieldsIsNullable.get(j)==0){
								System.out.printf("%-10s","NOT NULL");
							}else if(fieldsIsNullable.get(j)==1){
								System.out.printf("%-10s"," ");
							}else if(fieldsIsNullable.get(j)==1){
								System.out.printf("%-10s","UNKNOWN");
							}
							
							System.out.printf("%-10s(%d)",fieldsType.get(j),
									fieldsSize.get(j));
							System.out.println("");
						}
					 System.out.println();

				}else{

					stmt = con.createStatement();
					boolean state = stmt.execute(query);
					if(state){
						rs = stmt.getResultSet();
						rsmd = rs.getMetaData();
						int fields = rsmd.getColumnCount();
						ArrayList<String> fieldNames = new ArrayList<String>();
						for(int i = 1;i<=fields; i++){
							String fieldName =  rsmd.getColumnName(i);
							fieldNames.add(fieldName);
						}
						/*
						 * Process the query		
						 */

						for(int j=0;j<rsmd.getColumnCount();j++){
							System.out.printf("%10s  ",fieldNames.get(j));
						}
						System.out.println("\n");
						while(rs.next()){
							for(int j=0;j<rsmd.getColumnCount();j++){
								if(rsmd.getColumnType(j+1)==Types.DATE){
									System.out.printf("%10s  ",rs.getDate(fieldNames.get(j)));	
								}else{
									System.out.printf("%10s  ",rs.getString(fieldNames.get(j)));
								}
							}
							System.out.println();
						}
						System.out.println();


					}else{
						int i = stmt.getUpdateCount();
						System.out.println("Number of Rows Affected: "+i);
					}

				}

			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				
				closeJdbcObjects(rs, rsmd,stmt);
			}
		}else{
			System.out.println("Connection is null");
		}
	}//end of staticQuery

	/*
	 * closing all JDBC Objects
	 */
	public static void closeJdbcObjects(Object o1, Object o2, Object o3){
		/*
		 * 5- Closing Ceremony
		 */
		ArrayList<Object> obj = new ArrayList<Object>();
		obj.add(o1);
		obj.add(o2);
		obj.add(o3);

		Connection con=null;
		PreparedStatement pstmt=null;
		Statement stmt=null;
		CallableStatement cstmt=null;
		ResultSet rs=null;
		ResultSetMetaData rsmd = null;

		for(Object o:obj){
			if(o instanceof Connection){
				con = (Connection)o;
			}else if(o instanceof PreparedStatement){
				pstmt = (PreparedStatement)o;
			}else if(o instanceof Statement){
				stmt = (Statement)o;
			}else if(o instanceof CallableStatement){
				cstmt = (CallableStatement)o;
			}else if(o instanceof ResultSet){
				rs = (ResultSet)o;
			}else if(o instanceof ResultSetMetaData){
				rsmd = (ResultSetMetaData)o;
			}
		}

		if(con != null){
			try {
				con.close();
				System.out.println("Connection Closed");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if(pstmt != null){
			try {
				pstmt.close();
				System.out.println("PreparedStatement Closed");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if(stmt != null){
			try {
				stmt.close();
				System.out.println("Statement Closed");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if(cstmt != null){
			try {
				cstmt.close();
				System.out.println("CallableStatement Closed");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if(rs != null){
			try {
				rs.close();
				System.out.println("ResultSet Closed");
			} catch (SQLException e) {
				e.printStackTrace();
			}		
		}

	}//end of closeJdbcObject

	public static void closeJdbcObjects(Object o1, Object o2){
		/*
		 * 5- Closing Ceremony
		 */
		ArrayList<Object> obj = new ArrayList<Object>();
		obj.add(o1);
		obj.add(o2);

		Connection con=null;
		PreparedStatement pstmt=null;
		Statement stmt=null;
		CallableStatement cstmt=null;
		ResultSet rs=null;

		for(Object o:obj){
			if(o instanceof Connection){
				con = (Connection)o;
			}else if(o instanceof PreparedStatement){
				pstmt = (PreparedStatement)o;
			}else if(o instanceof Statement){
				stmt = (Statement)o;
			}else if(o instanceof CallableStatement){
				cstmt = (CallableStatement)o;
			}else if(o instanceof ResultSet){
				rs = (ResultSet)o;
			}
		}

		if(con != null){
			try {
				con.close();
				System.out.println("Connection Closed");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if(pstmt != null){
			try {
				pstmt.close();
				System.out.println("PreparedStatement Closed");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if(stmt != null){
			try {
				stmt.close();
				System.out.println("Statement Closed");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if(cstmt != null){
			try {
				cstmt.close();
				System.out.println("CallableStatement Closed");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if(rs != null){
			try {
				rs.close();
				System.out.println("ResultSet Closed");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


	}//end of closeJdbcObject

}
