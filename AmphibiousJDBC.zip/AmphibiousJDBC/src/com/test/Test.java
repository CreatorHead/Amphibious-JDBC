package com.test;

import java.sql.*;
import java.util.*;
import java.io.*;

import com.amphibious.AmphibiousJdbc;
import com.mysql.jdbc.Driver;
import oracle.jdbc.OracleDriver;

public class Test {

	public static void main(String[] args) {
		
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		String oracleDbUrl = "jdbc:oracle:thin:@127.0.0.1:1521:ORCL";
		String oracleDriverClass = "oracle.jdbc.OracleDriver";
		String oracleDbProperties = "F:\\PropertiesFiles\\OracleDB.properties";
		
		String mySqlDbUrl = "jdbc:mysql://localhost:3306/becme89_db";
		String mySqlDriverClass = "com.mysql.jdbc.Driver";
		String mySqlDbProperties = "F:\\PropertiesFiles\\DB.properties";
		
		FileReader reader = null;
		Properties property = null;
		
		File file = new File(oracleDbProperties);//please give the file path according to the rdbms
		try {
			reader = new FileReader(file);
			property = new Properties();
			property.load(reader);	
			
			String user = property.getProperty("user");
			String password = property.getProperty("password");
			
			/*
			 * Load and Connect
			 */
			con = AmphibiousJdbc.rockAndLoad(oracleDbUrl, user, password, oracleDriverClass);//pass data according to the RDBMS
			
			/*
			 * Issue the static query
			 */
			String query = "desc emp"; //*******Enter your query********
			AmphibiousJdbc.staticQuery(query, con);
			
			/*String query = "select * from students_info si, guardian_info gi,students_otherinflo soi "
							+"where si.regno = gi.regno"
							+ "and si.regno = soi.regno"
							+ "and soi.regno =?"
							+ "and soi.password =?";*/
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			AmphibiousJdbc.closeJdbcObjects(con,stmt,rs);
		}
	}//end of main
	
}
